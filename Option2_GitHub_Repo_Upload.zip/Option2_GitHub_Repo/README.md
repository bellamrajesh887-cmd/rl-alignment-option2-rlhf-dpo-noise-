# RLHF vs DPO Under Annotator Noise — Option 2

**Course project:** Reinforcement Learning and Language Model Alignment  
**Research question:** How does pairwise preference-label noise affect two simplified preference-alignment methods when both use matched data?

## Files
- `RL_Alignment_Option2_RLHF_vs_DPO_Noise.ipynb` — executed Google Colab notebook with the synthetic experiment, summary tables, plot, and seed-level analysis.
- `RL_Alignment_Option2_Report_Final.docx` — technical report based on the Colab results.
- `option2_noise_summary.csv` — summary metrics by noise level and method.
- `option2_seed_results.csv` — seed-level experiment results.
- `Option2_RLHF_DPO_Final_Results.png` — result plot used in the report.

## Experiment summary
The project compares an RLHF-style method that fits a feature-based reward model and a DPO-style method that directly optimizes from pairwise preferences. The simulated annotator flips gold-derived preference labels at 0%, 10%, 20%, and 40% rates. Results are evaluated with a transparent synthetic gold reward, a rule-based judge, output length, policy entropy, and intervals across 12 random seeds.

## Important scope note
This is a synthetic educational simulation. It does not fine-tune a pretrained language model and does not use real human preference data. The RLHF-style and DPO-style implementations are simplified feature-based analogues, not full neural-network training pipelines.

## How to run
1. Open the `.ipynb` file in Google Colab.
2. Choose **Runtime → Run all**.
3. Review the displayed tables and plot.
4. The notebook exports `option2_noise_summary.csv` and `option2_seed_results.csv`.

## Before submission
Replace author/register/date placeholders in the report, confirm the outputs after a clean run, and disclose AI assistance according to course requirements.
